package com.ubs.opsit.interviews;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.Test;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

/*
 * This is a unit test for testing the implementation class of TimeConverter
 */
public class TimeConverterTest {

	private TimeConverterImpl timeConverterImpl;

	public TimeConverterTest() {
		timeConverterImpl = new TimeConverterImpl();
	}

	/**
	 * Test the method of converting to Date object
	 */
	@Test
	public void test1_ConvertToDate() {
		try {
			final StringBuilder aTime = new StringBuilder("23:23:23");
			final Date expectedResult = new SimpleDateFormat(
					"yyyy-mm-dd hh:mm:ss").parse("1970-01-01 "
					+ aTime.toString());

			assertThat(timeConverterImpl.convertStringToDate(aTime.toString()),
					is(equalTo(expectedResult)));

		} catch (ParseException e) {

			throw new TimeConverterException(e);
		}
	}

	/**
	 * Test second
	 */
	@Test
	public void test2_Second() {

		try {

			final StringBuilder aTime = new StringBuilder("23:23:23");
			final Date input = getGenerateDate(aTime.toString());

			final StringBuilder expectedResult = new StringBuilder("O");
			assertThat(timeConverterImpl.getSecond(input),
					is(equalTo(expectedResult.toString())));
		} catch (TimeConverterException e) {

			throw new TimeConverterException(e);
		}

	}

	/**
	 * Test minute in first row
	 */
	@Test
	public void test3_MinuteInFirstRow() {

		try {

			final StringBuilder aTime = new StringBuilder("23:23:23");
			final Date input = getGenerateDate(aTime.toString());
			final StringBuilder expectedResult = new StringBuilder(
					"YYRYOOOOOOO");
			assertThat(timeConverterImpl.getMinuteInFirstRow(input),
					is(equalTo(expectedResult.toString())));
		} catch (TimeConverterException e) {

			throw new TimeConverterException(e);
		}
	}

	/**
	 * test minute in second row
	 */
	@Test
	public void test4_MinuteInSecondRow() {
		try {

			final StringBuilder aTime = new StringBuilder("23:23:23");
			final Date input = getGenerateDate(aTime.toString());
			final StringBuilder expectedResult = new StringBuilder("YYYO");
			assertThat(timeConverterImpl.getMinuteInSecondRow(input),
					is(equalTo(expectedResult.toString())));
		} catch (TimeConverterException e) {

			throw new TimeConverterException(e);
		}
	}

	/**
	 * Test hours in first row
	 */
	@Test
	public void test5_HourInFirstRow() {

		try {
			final StringBuilder aTime = new StringBuilder("24:00:00");
			final Date input = getGenerateDate(aTime.toString());

			final StringBuilder expectedResult = new StringBuilder("RRRR");
			assertThat(timeConverterImpl.getHourInFirstRow(input),
					is(equalTo(expectedResult.toString())));
		} catch (TimeConverterException e) {

			throw new TimeConverterException(e);
		}
	}

	/**
	 * Test hours in second row
	 */
	@Test
	public void test6_HourInSecondRow() {

		try {
			final StringBuilder aTime = new StringBuilder("23:23:23");
			final Date input = getGenerateDate(aTime.toString());
			final StringBuilder expectedResult = new StringBuilder("RRRO");
			assertThat(timeConverterImpl.getHourInSecondRow(input),
					is(equalTo(expectedResult.toString())));
		} catch (TimeConverterException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * Test nullpointerException
	 */
	@Test(expected=NullPointerException.class)
	public void test7_NullPointerCheck(){
		timeConverterImpl.convertStringToDate(null);
	}
	
	/**
	 * Test nullpointerException
	 */
	@Test(expected=TimeConverterException.class)
	public void test8_NumberFormatCheck(){
		timeConverterImpl.convertStringToDate("");
	
	}
	
	

	private Date getGenerateDate(String aTime) {

		try {
			return new SimpleDateFormat("yyyy-mm-dd hh:mm:ss")
					.parse("1970-01-01 " + aTime);
		} catch (ParseException e) {
			throw new TimeConverterException(e);
		}

	}
}
