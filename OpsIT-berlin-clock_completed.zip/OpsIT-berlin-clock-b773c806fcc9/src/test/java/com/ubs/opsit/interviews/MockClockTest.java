package com.ubs.opsit.interviews;

import org.junit.Test;

import static org.mockito.Mockito.mock;

import static org.mockito.Mockito.when;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

public class MockClockTest {

	@Test
	public void testMock() {
		final StringBuilder expectedResult = new StringBuilder();
		expectedResult.append("O\n");
		expectedResult.append("RROO\n");
		expectedResult.append("RRRO\n");
		expectedResult.append("YYROOOOOO0O\n");
		expectedResult.append("YYOO\n");

		TimeConverter timeConverterMock = mock(TimeConverter.class);
		when(timeConverterMock.convertTime("13:17:01")).thenReturn(
				expectedResult.toString());
		assertThat(expectedResult.toString(),
				is(equalTo(timeConverterMock.convertTime("13:17:01"))));
	}
}
