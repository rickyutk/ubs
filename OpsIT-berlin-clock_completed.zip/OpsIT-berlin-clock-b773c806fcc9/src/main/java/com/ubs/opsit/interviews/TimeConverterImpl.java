package com.ubs.opsit.interviews;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedList;
import java.util.Queue;

import com.ubs.opsit.interviews.enums.LampColorEnum;

/**
 * This is the implemenation class for the interface of Time Converter
 * 
 * @author rlui
 * 
 */
public class TimeConverterImpl implements TimeConverter {

	final static int SECONDDIVIDEND = 2;
	final static int HOURDIVIDEND = 5;
	final static int MINUTEDIVIDEND = 5;
	final static int MINUTELAMPCOLOR = 3;

	final static int TWO = 2;
	final static int TWENTYFOUR = 24;
	final static int FOURLAMP = 4;
	final static int ELEVENLAMP = 11;

	final static String NEWLINE = "\n";
	final private Queue<String> queue = new LinkedList<String>();

	private Calendar calendar;

	/**
	 * Constructor
	 */
	public TimeConverterImpl() {
		calendar = Calendar.getInstance();
	}

	/**
	 * Convert a time in string to a displaying time format on the clock
	 */
	@Override
	public String convertTime(String aTime) {

		final StringBuilder stringBuilder = new StringBuilder();
		//Set the displaying order
		controller(aTime);
		while (!queue.isEmpty()) {
			
			stringBuilder.append(queue.remove());
			//display a new line 
			if (!queue.isEmpty()) {
				stringBuilder.append(NEWLINE);
			}

		}

		return stringBuilder.toString();
	}

	/**
	 * Controlling the order of the lamp color
	 * 
	 * @param aTime
	 */
	private void controller(final String aTime) {
		if (aTime == null) {
			throw new RuntimeException();
		}
		//Convert time in string to a date object
		final Date aDate = convertStringToDate(aTime);
		queue.add(getSecond(aDate));
		queue.add(getHourInFirstRow(aDate));
		queue.add(getHourInSecondRow(aDate));

		queue.add(getMinuteInFirstRow(aDate));
		queue.add(getMinuteInSecondRow(aDate));

	}

	/**
	 * Convert time in string type to date type
	 * 
	 * @param aTime
	 * @return Date
	 */
	protected Date convertStringToDate(final String aTime) {

		try {
			if(aTime==null){
				throw new NullPointerException();
			}
			// Acceptance object is HH:mm:ss
			final DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
			return dateFormat.parse(aTime);
		} catch (ParseException e) {
			
			throw new TimeConverterException(e);
		}
	}

	/**
	 * The Berlin Uhr (Clock) is a rather strange way to show the time. On the
	 * top of the clock there is a yellow lamp that blinks on/off every two
	 * seconds. The time is calculated by adding rectangular lamps.
	 */
	protected String getSecond(final Date date) {
		//Reset the calendar object
		calendar.clear();
		calendar.setTime(date);
		
		//if the second is an even number, display a 'Y'
		//otherwise, O
		int remainder = calendar.get(Calendar.SECOND) % SECONDDIVIDEND;
		if (remainder == 1) {
			return LampColorEnum.O.name();
		} else {
			return LampColorEnum.Y.name();
		}

	}

	/**
	 * Top row, the top two rows of lamps are red. These indicate the hours of a
	 * day. In the top row there are 4 red lamps. Every lamp represents 5 hours.
	 * In the lower row of red lamps every lamp represents 1 hour. So if two
	 * lamps of the first row and three of the second row are switched on that
	 * indicates 5+5+3=13h or 1 pm.
	 * 
	 * @param date
	 * @return String
	 */
	protected String getHourInFirstRow(final Date date) {
		//Reset the calendar object
		calendar.clear();
		calendar.setTime(date);
		int numberOfRed;

		if (calendar.get(Calendar.HOUR_OF_DAY) == 0) {
			
			//if the time is 24, it returns 24
			//otherwise, it returns 00
			numberOfRed = calendar.get(Calendar.DAY_OF_MONTH) == TWO ? TWENTYFOUR
					: calendar.get(Calendar.HOUR_OF_DAY) / HOURDIVIDEND;
		} else {
			numberOfRed = calendar.get(Calendar.HOUR_OF_DAY) / HOURDIVIDEND;
		}

		final StringBuilder hoursInRed = new StringBuilder();

		//display R color for representing the hour
		for (int i = 0; i < FOURLAMP; i++) {
			if (numberOfRed > i) {
				hoursInRed.append(LampColorEnum.R);
			} else {
				hoursInRed.append(LampColorEnum.O);
			}
		}
		return hoursInRed.toString();
	}

	/**
	 * Button row, the top two rows of lamps are red. These indicate the hours
	 * of a day. In the top row there are 4 red lamps. Every lamp represents 5
	 * hours. In the lower row of red lamps every lamp represents 1 hour. So if
	 * two lamps of the first row and three of the second row are switched on
	 * that indicates 5+5+3=13h or 1 pm.
	 * 
	 * @param date
	 * @return String
	 */
	protected String getHourInSecondRow(final Date date) {
		//Reset the calendar object
		calendar.clear();
		calendar.setTime(date);
		
		int remainder;
		//checking the hour is 24 or 00
		if (calendar.get(Calendar.HOUR_OF_DAY) == 0) {

			//if the time is 24, it returns 24
			//otherwise, it returns 00
			remainder = calendar.get(Calendar.DAY_OF_MONTH) == TWO ? TWENTYFOUR
					: calendar.get(Calendar.HOUR_OF_DAY) % HOURDIVIDEND;

		} else {
			
			remainder = calendar.get(Calendar.HOUR_OF_DAY) % HOURDIVIDEND;
		}

		final StringBuilder hours = new StringBuilder();


		//display R color for representing the hour
		for (int i = 0; i < FOURLAMP; i++) {
			if (remainder > i) {
				hours.append(LampColorEnum.R);
			} else {
				hours.append(LampColorEnum.O);
			}
		}
		return hours.toString();

	}

	/**
	 * Top row, the two rows of lamps at the bottom count the minutes. The first
	 * of these rows has 11 lamps, the second 4. In the first row every lamp
	 * represents 5 minutes. In this first row the 3rd, 6th and 9th lamp are red
	 * and indicate the first quarter, half and last quarter of an hour. The
	 * other lamps are yellow. In the last row with 4 lamps every lamp
	 * represents 1 minute.
	 * 
	 * @param date
	 * @return String
	 */
	protected String getMinuteInFirstRow(final Date date) {
		
		//Reset the calendar object
		calendar.clear();
		calendar.setTime(date);

		final StringBuilder minutesInRed = new StringBuilder();
		final int numberOfRed = calendar.get(Calendar.MINUTE) / MINUTEDIVIDEND;

		// There are 11 lamps on the top row of the minute
		for (int i = 0; i < ELEVENLAMP; i++) {
			if (numberOfRed > i) {

				//if the time is quarter, half or last quarter,
				//display red color
				//otherwise, yellow color
				if ((i + 1) % MINUTELAMPCOLOR == 0) {
					minutesInRed.append(LampColorEnum.R);
				} else {
					minutesInRed.append(LampColorEnum.Y);
				}
			} else {
				minutesInRed.append(LampColorEnum.O);
			}
		}
		return minutesInRed.toString();
	}

	/**
	 * Button row, the two rows of lamps at the bottom count the minutes. The
	 * first of these rows has 11 lamps, the second 4. In the first row every
	 * lamp represents 5 minutes. In this first row the 3rd, 6th and 9th lamp
	 * are red and indicate the first quarter, half and last quarter of an hour.
	 * The other lamps are yellow. In the last row with 4 lamps every lamp
	 * represents 1 minute.
	 * 
	 * @param date
	 * @return String
	 */
	protected String getMinuteInSecondRow(final Date date) {
		//Reset the calendar object
		calendar.clear();
		calendar.setTime(date);

		final StringBuilder minutes = new StringBuilder();
		final int remainder = calendar.get(Calendar.MINUTE) % MINUTEDIVIDEND;

		//display Y color for representing the minute
		for (int i = 0; i < FOURLAMP; i++) {
			if (remainder > i) {
				minutes.append(LampColorEnum.Y);
			} else {
				minutes.append(LampColorEnum.O);
			}
		}
		return minutes.toString();
	}

}
