package com.ubs.opsit.interviews;

public class TimeConverterException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4101767392846987025L;

	public TimeConverterException(final String message){
		super(message);
	}
	
	public TimeConverterException(final Throwable message){
		super(message);
	}
}
