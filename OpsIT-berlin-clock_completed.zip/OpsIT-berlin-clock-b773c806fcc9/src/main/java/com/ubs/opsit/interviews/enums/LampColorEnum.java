package com.ubs.opsit.interviews.enums;

public enum LampColorEnum {
	Y, R, O;
}
